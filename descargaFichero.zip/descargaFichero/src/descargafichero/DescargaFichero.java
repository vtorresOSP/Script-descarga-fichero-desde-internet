/*
Víctor Torres
30 abril 2019
 */
package descargafichero;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class DescargaFichero {

    /**
     * Descargar un determinado fichero y guardarlo en ruta específica.
     */
    public static void main(String[] args) {
        try {
            // Url con la foto
            URL url = new URL(
                    "https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_10mb.mp4");

            // Abrir la conexión con el método URLConnection.
            URLConnection urlCon = url.openConnection();
            
            // Se obtiene el inputStream del fichero a guardarse en el direcotorio local.
            // Si el fichero ya existe con el mismo nombre, será sobreescrito.
            InputStream is = urlCon.getInputStream();
            FileOutputStream fos = new FileOutputStream("C:/Users/OSP2019/Documents/NetBeansProjects/videodummy.mp4");

            // Lectura del fichero de la web y escritura en directorio local.
            byte[] array = new byte[1000]; // buffer temporal de lectura.
            int leido = is.read(array);
            while (leido > 0) {
                fos.write(array, 0, leido);
                leido = is.read(array);
            }

            // Cierre de la conexion y del fichero.
            is.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
